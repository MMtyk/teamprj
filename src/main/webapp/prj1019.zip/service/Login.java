package service;

import vo.LoginVO;

public class Login {
	ILogin is;
	public Login() {
	is = new LoginImpl();
	}
	
	public String add(LoginVO vo) {
		return is.add(vo);
	}
}
