package service;

import vo.LoginVO;

public interface ILogin {
	String add(LoginVO vo);
}