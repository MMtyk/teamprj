package service;

import java.sql.*;
import vo.LoginVO;

public class LoginImpl implements ILogin {
	public LoginImpl() {
		
	}

	public String add(LoginVO vo) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");	
		}catch(ClassNotFoundException e ) {
			e.printStackTrace();
		}
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "SCOTT";
		String pass = "TIGER";
		try {
			Connection con = DriverManager.getConnection(url,user,pass);
			String query = "SELECT pwd FROM account where name='" +vo.getId()+"'";
			PreparedStatement pstmt = con.prepareStatement(query); 
			ResultSet rs = pstmt.executeQuery();
					
			String pwd = null;
			while(rs.next())
                pwd=rs.getString("pwd").trim();

	        rs.close();
	        pstmt.close();
	        con.close();
			return pwd;
		}catch(SQLException e) {
			e.printStackTrace();
			System.out.println("err");
			return "1234";
		}
	}
}
