package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.LoginImpl;
import service.ILogin;
import vo.LoginVO;

@WebServlet("/CalServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1. 媛� 異�異�
		//2. 媛� 蹂���
		try {
			String op1 = request.getParameter("op1");
			String op2 = request.getParameter("op2");
			//4. ��鍮��� �몄�
			ILogin cs = new LoginImpl();
			LoginVO vo = new LoginVO(op1, op2);
			request.setAttribute("op1", vo.getId());
			request.setAttribute("op2", vo.getPasswd());
			//3. 媛� 寃�利�
				if(vo.getPasswd().equals(cs.add(vo))) {
					request.setAttribute("op3", "O");
					RequestDispatcher view = request.getRequestDispatcher("view/cal.jsp");
					view.forward(request,  response);
				}
				else {
					request.setAttribute("op3", vo.getPasswd() + vo.getId() + cs.add(vo));
					RequestDispatcher view = request.getRequestDispatcher("view/error.jsp");
					view.forward(request,  response);
				}

		}catch(Exception e) {
			//6. ���몄�由�
			request.setAttribute("op3", "?");
			RequestDispatcher view = request.getRequestDispatcher("view/error.jsp");
			view.forward(request,  response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
